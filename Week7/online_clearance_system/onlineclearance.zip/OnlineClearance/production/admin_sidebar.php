<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
	<div class="menu_section">
		<h3>General</h3>
		<ul class="nav side-menu">
			<li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
				<ul class="nav child_menu">
					<li><a href="admin1.php">Masters List</a></li>
					<li><a href="admin_list_talisay.php">CHMSC-Talisay</a></li>
					<li><a href="admin_list_alijis.php">CHMSC-Alijis</a></li>
					<li><a href="admin_list_binalbagan.php">CHMSC-Binalbagan</a></li>
					<li><a href="admin_list_ftowne.php">CHMSC-Fortune Towne</a></li>
					<li><a href="admin_list_allcleared.php">List of All Cleared Faculty</a></li>
					<li><a href="admin_list_allinactive.php">List of All Inactive Faculty</a></li>
					<li><a href="admin.php">List by Department</a></li>
					<li><a href="javascript:;" data-toggle="modal" data-target="#set_deadline">Set deadline</a></li>
				</ul>
			</li>
		</ul>
	</div>
</div>