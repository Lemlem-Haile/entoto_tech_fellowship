<div class="modal fade" id="myModal_user" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Add Faculty</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<form action="add_admin.php" method="POST">
						<div class="Id">
							<label>	Username</label>
							<input type="" class="form-control" name= "admin_username" placeholder="Username" required>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>